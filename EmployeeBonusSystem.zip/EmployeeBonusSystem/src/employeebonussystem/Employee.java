/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package employeebonussystem;

import java.util.Scanner;

/**
 *
 * @author joshu
 */
class Employee {

    public String getName() {
        return name;
    }

    public int getEmployeeId() {
        return employeeId;
    }

    public double[] getPerformanceMetrics() {
        return performanceMetrics;
    }
    protected String name;
    protected int employeeId;
    protected double[] performanceMetrics;

    public Employee(String name, int employeeId, int numMetrics) {
        this.name = name;
        this.employeeId = employeeId;
        this.performanceMetrics = new double[numMetrics];
    }
    public double calculateAverageMetrics() {
        double sum = 0;
        for (double metric : performanceMetrics) {
            sum += metric;
        }
        return sum / performanceMetrics.length;
    }
    public void inputPerformanceMetrics() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter years worked for " + name);
        for (int i = 0; i < performanceMetrics.length; i++) {
            try {
                System.out.print("Year " + (i + 1) + ": ");
                performanceMetrics[i] = scanner.nextDouble();
            } catch (java.util.InputMismatchException e) {
                System.out.println("Invalid input. Please enter a numeric value for the years worked!!!");
                
                scanner.nextLine();
                i--; // Re-enter the current metric
        }
    }}

    public void calculateBonus() {
        // Implement bonus calculation logic for regular employees here
    }

    public void displayEmployeeDetails() {
        System.out.println("Employee ID: " + employeeId);
        System.out.println("Name: " + name);
        System.out.println("Years worked:" + performanceMetrics.length);
        for (int i = 0; i < performanceMetrics.length; i++) {
            System.out.println("Year: " + (i + 1) + ": " + performanceMetrics[i]);
        }
    }
}

// Subclass for Regular Employees
class RegularEmployee extends Employee {
    public RegularEmployee(String name, int employeeId, int numMetrics) {
        super(name, employeeId, numMetrics);
    }

    @Override
    public void calculateBonus() {
        double bonus = calculateAverageMetrics() * 0.10;
        System.out.println("Bonus: " + bonus);
    }
}

// Subclass for Manager Employees
class ManagerEmployee extends Employee {
    public ManagerEmployee(String name, int employeeId, int numMetrics) {
        super(name, employeeId, numMetrics);
    }

    @Override
    public void calculateBonus() {
        double bonus = calculateAverageMetrics() * 0.15;
        System.out.println("Bonus: " + bonus);
    }
}
