/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package employeebonussystem;

import java.util.Scanner;

/**
 *
 * @author joshu
 */
public class EmployeeBonusSystem {

    /**
     * @param args the command line arguments
     */
       public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
           System.out.println("Welcome to Employee Bonus System\n"
                   + "Please enter the number of employees and their details.\n"
                   + "Enter performance metrics as yearly salaries, Minimum 1 year.\n"
                   + "The program will output your employees average results.\n"
                   + "The program will output your Bonus achieved.\n"
                   + "Employees with Manager status will be given greater bonuses.");
        // Input the number of employees
        System.out.print("Enter the number of employees: ");
        int numEmployees = scanner.nextInt();

        Employee[] employees = new Employee[numEmployees];

        // Input employee data
        for (int i = 0; i < numEmployees; i++) {
            System.out.println("Employee " + (i + 1) + " details:");
            System.out.print("Name: ");
            String name = scanner.next();
            System.out.print("Employee ID: ");
            int employeeId = scanner.nextInt();
            System.out.print("Number of years worked: ");
            int numMetrics = scanner.nextInt();

            // Create Regular or Manager Employee based on user input
            String employeeType = null;
            boolean validInput = false;
            while (!validInput) {
                System.out.print("Enter employee type R or M (Regular/Manager): ");
                employeeType = scanner.next();
                if (employeeType.equalsIgnoreCase("R") || employeeType.equalsIgnoreCase("M")) {
                    validInput = true;
                } else {
                    System.out.println("Invalid input. Please enter R for Regular or M for Manager.");
                }
            }

            if (employeeType.equalsIgnoreCase("R")) {
                employees[i] = new RegularEmployee(name, employeeId, numMetrics);
            } else if (employeeType.equalsIgnoreCase("M")) {
                employees[i] = new ManagerEmployee(name, employeeId, numMetrics);
            }

            // Input performance metrics
            employees[i].inputPerformanceMetrics();
        }

        // Calculate and display bonuses and aveage metrics
        for (Employee employee : employees) {
            
            employee.displayEmployeeDetails();
            employee.calculateBonus();
            double averageMetrics = employee.calculateAverageMetrics();
            System.out.println("Average Metrics: " + averageMetrics);
        }
    }
    }
    

