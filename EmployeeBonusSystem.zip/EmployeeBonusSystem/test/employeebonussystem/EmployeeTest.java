/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package employeebonussystem;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import org.junit.Test;

/**
 *
 * @author joshu
 */
public class EmployeeTest {
   private Employee employee;
   
@Test
    public void testDisplayEmployeeDetails() {
    employee = new RegularEmployee("John Doe", 12345, 5);
    double[] performanceMetrics = {85000.0, 90000.0, 78000.0, 92000.0, 88000.0};
    employee.performanceMetrics = performanceMetrics;
    ByteArrayOutputStream outContent = new ByteArrayOutputStream();
    System.setOut(new PrintStream(outContent));
    employee.displayEmployeeDetails();

    // Assert the values using getters
    assertEquals("John Doe", employee.getName());
    assertEquals(12345, employee.getEmployeeId());
    assertArrayEquals(performanceMetrics, employee.getPerformanceMetrics(), 0.01); // Use delta for double comparison
    }



    @Test
    public void testCalculateBonus() {
        employee = new RegularEmployee("John Doe", 12345, 5);
        double[] performanceMetrics = {85.0, 90.0, 78.0, 92.0, 88.0}; 
        employee.performanceMetrics = performanceMetrics;
    }

    @Test
    public void testCalculateAverageMetrics() {
        employee = new RegularEmployee("John Doe", 12345, 5);
        double[] performanceMetrics = {85.0, 90.0, 78.0, 92.0, 88.0};
        employee.performanceMetrics = performanceMetrics;
        double expectedAverage = (85.0 + 90.0 + 78.0 + 92.0 + 88.0) / 5.0;
        double actualAverage = employee.calculateAverageMetrics();
        assertEquals(expectedAverage, actualAverage, 0.01);
    }
    
}
