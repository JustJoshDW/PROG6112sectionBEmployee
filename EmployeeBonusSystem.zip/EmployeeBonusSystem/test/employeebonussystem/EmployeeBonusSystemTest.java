/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package employeebonussystem;

import org.junit.Test;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import static org.junit.Assert.assertEquals;

/**
 *
 * @author joshu
 */
public class EmployeeBonusSystemTest {
    
     Employee employee ;
   
    @Test
    public void testDisplayEmployeeDetails() {
        Employee employee ;
        employee = new RegularEmployee("John Doe", 12345, 5);
        double[] performanceMetrics = {85000.0, 90000.0, 78000.0, 92000.0, 88000.0};
        employee.performanceMetrics = performanceMetrics;
        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));
        employee.displayEmployeeDetails();
        String expectedOutput = "Employee ID: 12345\nName: John Doe\nYears worked: 5\nYear 1: 85.0\nYear 2: 90.0\nYear 3: 78.0\nYear 4: 92.0\nYear 5: 88.0\n";
        assertEquals(expectedOutput, outContent.toString());
    }

    @Test
    public void testCalculateBonus() {
        employee = new RegularEmployee("John Doe", 12345, 5);
        double[] performanceMetrics = {85.0, 90.0, 78.0, 92.0, 88.0}; 
        employee.performanceMetrics = performanceMetrics;
    }

    @Test
    public void testCalculateAverageMetrics() {
        employee = new RegularEmployee("John Doe", 12345, 5);
        double[] performanceMetrics = {85.0, 90.0, 78.0, 92.0, 88.0};
        employee.performanceMetrics = performanceMetrics;
        double expectedAverage = (85.0 + 90.0 + 78.0 + 92.0 + 88.0) / 5.0;
        double actualAverage = employee.calculateAverageMetrics();
        assertEquals(expectedAverage, actualAverage, 0.01);
    }
    
}
